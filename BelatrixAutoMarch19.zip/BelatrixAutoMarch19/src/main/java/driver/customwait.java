package driver;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import static driver.driver.DriverBela;


public class customwait {

   public void implicitwait ()
   {
       try{
           Thread.sleep(8000);
       }
       catch(InterruptedException ie){
       }

   }
      public void explicitwait()
   {

       ExpectedCondition<Boolean> expectation = new
               ExpectedCondition<Boolean>() {
                   public Boolean apply(WebDriver DriverBela) {
                       return ((JavascriptExecutor) DriverBela).executeScript("return document.readyState").toString().equals("complete");
                   }
               };
       try {
           Thread.sleep(1000);
           WebDriverWait wait = new WebDriverWait(DriverBela, 30);
           wait.until(expectation);
       } catch (Throwable error) {
           System.out.println("Timeout waiting for Page Load Request to complete.");
       }
   }






   }


