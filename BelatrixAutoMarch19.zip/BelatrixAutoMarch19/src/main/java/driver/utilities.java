package driver;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebDriver;

public class utilities {


    public void scrollDownToBottom(WebDriver x) {
        JavascriptExecutor jse = ((JavascriptExecutor)  x);
        jse.executeScript("window.scrollTo(0, document.body.scrollHeight - 10)");
    }
}
