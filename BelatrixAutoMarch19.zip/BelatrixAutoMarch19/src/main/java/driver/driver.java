package driver;

import io.github.bonigarcia.wdm.ChromeDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;


import static io.github.bonigarcia.wdm.DriverManagerType.CHROME;

public class driver {
public static WebDriver DriverBela;
private String baseUrl;
public static customwait belawait;
public static Actions act;


    public driver() {


        ChromeDriverManager.getInstance(CHROME).setup();
       DriverBela = new ChromeDriver();
       this.baseUrl = "https://www.ebay.com";
       DriverBela.get(baseUrl);
        DriverBela.manage().window().maximize();


    }




}
