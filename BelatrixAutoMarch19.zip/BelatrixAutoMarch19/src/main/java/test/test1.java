package test;

import POM.EbayHome;
import POM.Ebayslp;
import driver.driver;
import entities.productslp;

import static driver.driver.belawait;


import static driver.driver.DriverBela;

public class test1 {

    public static void main(String[] args) throws InterruptedException {

    new driver();

        EbayHome page1 = new EbayHome();
        page1.ebaysearch();
        Ebayslp slp = new Ebayslp();
         slp.markcheckbox();
         slp.printresults();
         slp.OrderByPriceAsc();
        productslp[] aux = slp.selectXitems(2);
        System.out.println("entro a compare products ");
        compareproducts com = new compareproducts();
        com.compare(aux);

        if (com.correctorder())
        {System.out.println("Bien ordenado por ebay");}
        else
        {System.out.println("mal ordenado por ebay");}

        com.printproducts();
        //no lo he probado---corregir los booleanos
        /*
        com.OrdenadoxNombre();
        com.printproducts();
        com.OrdenadoxPrecioDesc();
        com.printproducts();
*/

DriverBela.quit();



    }
}
