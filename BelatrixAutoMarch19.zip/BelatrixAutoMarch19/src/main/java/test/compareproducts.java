package test;

import entities.productslp;

import java.util.Arrays;

public class compareproducts {

String aux22;
String aux23;
Float Shippingplusprice;
productslp[] listaproductos2;


    public void compare(productslp[] x )
    {

System.out.println(x.length);
        for (int i = 0 ; i < x.length ; i++) {


            aux22 = x[i].getSprice();
            System.out.println(aux22);
            aux23 = x[i].getSshipping();
            System.out.println(aux23);


            int numeroaux = aux22.length();
            aux22 = aux22.substring(4, numeroaux);

/*
            int numero2aux = aux23.length();
            aux23 = aux23.substring(5, numero2aux);
*/


            String string = aux23;

            String[] parts = string.split(" ");
            String part1 = parts[0];
            String part2 = parts[1];
            aux23 = part2;
            System.out.println(aux23);

            Boolean t = Character.isDigit(aux23.charAt(1));





            if (t) {
                Float numero = Float.parseFloat(aux22);
                Float numero2 = Float.parseFloat((aux23));
                Shippingplusprice = numero + numero2;
            } else {
                Float numero = Float.parseFloat((aux22));
                Shippingplusprice =numero;
            }

            x[i].setPrice(Shippingplusprice);

        }

        listaproductos2 = x;
    }

    public boolean correctorder()
    {
        boolean t = true;
        for (int i = 0; i< listaproductos2.length ; i++)
        {
            if (i+1<listaproductos2.length) {
                if (listaproductos2[i].getPrice() < listaproductos2[i + 1].getPrice()) {
                    t = true;

                } else {
                    t = false;

                }
            }

        }

        return t;

    }

    public void printproducts() {
        int i2 =1;
        for (int i = 0; i < listaproductos2.length; i++) {

            System.out.println("Product" + i2);
            System.out.println(listaproductos2[i].getName());
            System.out.println(listaproductos2[i].getSprice());
            System.out.println(listaproductos2[i].getSshipping());
            i2++;
        }
    }



    public void OrdenadoxNombre()
    {
        Boolean T = true;

        while  (T)
        {

            for( int i = 0; i < listaproductos2.length; i++)
            {

                if (i+1 < listaproductos2.length) {
                    String a = listaproductos2[i].getName();
                    String b = listaproductos2[i + 1].getName();
                    String[] array1 = {a.toLowerCase(), b.toLowerCase()};
                    String[] array2 = {a.toLowerCase(), b.toLowerCase()};
                    Arrays.sort(array2);
                    if (Arrays.equals(array1, array2)) {
                        T = false;
                    } else {
                        productslp aux33 = new productslp();
                        aux33 = listaproductos2[i];
                        listaproductos2[i] = listaproductos2[i + 1];
                        listaproductos2[i + 1] = aux33;
                        T = true;

                    }
                }

            }

        }



    }

    public void OrdenadoxPrecioDesc()
    {
        Boolean T = true;

        while  (T)
        {

            for( int i = 0; i < listaproductos2.length; i++)
            {

                if (i+1 < listaproductos2.length) {


                    if (listaproductos2[i].getPrice()<listaproductos2[i+1].getPrice())
                    {
                        productslp aux20 = new productslp();
                        aux20 = listaproductos2[i];
                        listaproductos2[i] = listaproductos2[i + 1];
                        listaproductos2[i + 1] = aux20;
                        T = true;

                    }
                    else
                    {
                        T=T^false;

                    }


                    }
                }




        }


    }

}
