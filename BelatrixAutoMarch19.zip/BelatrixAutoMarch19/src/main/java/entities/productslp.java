package entities;

public class productslp {

    private String Sprice;
    private String Sshipping;
    private Float price;
    private Float shipping;
    private String name;


    public String getSprice() {
        return Sprice;
    }

    public void setSprice(String sprice) {
        Sprice = sprice;
    }

    public String getSshipping() {
        return Sshipping;
    }

    public void setSshipping(String sshipping) {
        Sshipping = sshipping;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public Float getShipping() {
        return shipping;
    }

    public void setShipping(Float shipping) {
        this.shipping = shipping;
    }
}
