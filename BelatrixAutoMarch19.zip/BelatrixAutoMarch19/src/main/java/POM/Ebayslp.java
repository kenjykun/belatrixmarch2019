package POM;

import entities.productslp;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import static driver.driver.DriverBela;


public class Ebayslp {


By sizecheckbox = By.xpath("//*[@id=\'refineOverlay-subPanel-US%20Shoe%20Size%20%28Men%27s%29_10_cbx\']");
By panelsize = By.xpath("//*[@id=\'w3-w0-w2-w0\']/button");
By SubButton = By.xpath("//*[@id='refineOverlay-footerId']/div[2]/button");
By searchresults = By.xpath("//*[@id=\'w4\']/div[2]/div/div[1]/h1");

By ResOrder = By.xpath("//*[@id=\'w4-w1\']/button/div/div");
By PriceAsc = By.xpath("//*[@id=\'w4-w1\']/div/div/ul/li[4]/a/span");
//By listview = By.xpath("//*[@id=\'w4-w2\']/button/div");
By listview = By.xpath("//*[@id=\'w4\']/div[1]/div[3]/div[2]");

By category = By.xpath("//*[@id=\'w4-w2-w0\']/a/div/span");


String part1 ="//*[@id=\'srp-river-results-listing";
String part2 ="']/div/div[2]/div[3]/div[1]/span/span";

String part3 ="//*[@id=\'srp-river-results-listing";
String part4 ="']/div/div[2]/div[3]/div[3]/span/span";

String part5 ="//*[@id='srp-river-results-listing";
String part6 ="']/div/div[2]/a/h3";






    public void markcheckbox () throws InterruptedException {

        Thread.sleep(2000);


        DriverBela.findElement(panelsize).click();
        Thread.sleep(2000);


    Boolean a = DriverBela.findElement(sizecheckbox).isDisplayed();
    Boolean b = DriverBela.findElement(sizecheckbox).isEnabled();
    Boolean c = DriverBela.findElement(sizecheckbox).isSelected();



            Thread.sleep(4000);

    if ( a && b && (c == false))
    {

        DriverBela.findElement(sizecheckbox).click();
        Thread.sleep(3000);
    }

        DriverBela.findElement(SubButton).click();
        Thread.sleep(3000);
}


public void printresults ()
{

    String aux = DriverBela.findElement(searchresults).getText();
    System.out.println(aux);
}

public void OrderByPriceAsc() throws InterruptedException {


    Thread.sleep(5000);
    WebElement aux2 = DriverBela.findElement(ResOrder);
    Actions act = new Actions(DriverBela);
    act.moveToElement(aux2).build().perform();
    Thread.sleep(5000);
    DriverBela.findElement(PriceAsc).click();
    Thread.sleep(5000);

}

public productslp[] selectXitems(int x) throws InterruptedException {

        Thread.sleep(5000);
    Actions act2 = new Actions(DriverBela);

    WebElement aux3 = DriverBela.findElement(listview);
    act2.moveToElement(aux3).build().perform();
    DriverBela.findElement(category).click();
    Thread.sleep(5000);

    productslp[] listofproducts = new productslp[x];


    int i ;
    int i2 = 1;
    for (i = 0; i<x ; i++)
    {


        String exp1 = part1+ i2 + part2;
        String exp2 = part3+ i2 + part4;
        String exp3 = part5+ i2 + part6;
        String aux22 = "";
        String aux23 = "";
        String aux24 = "";


        aux22 = DriverBela.findElement(By.xpath(exp1)).getText();
        aux23 = DriverBela.findElement(By.xpath(exp2)).getText();
        aux24 = DriverBela.findElement(By.xpath(exp3)).getText();


        productslp prod = new productslp();
        prod.setSprice(aux22);
        prod.setSshipping(aux23);
        prod.setName(aux24);

        listofproducts[i] = new productslp();
        listofproducts[i] = prod;

        //agregar un scroll down

i2++;
    }

 return listofproducts;

}





}

