package POM;

import org.openqa.selenium.By;
import static driver.driver.DriverBela;
import static driver.driver.belawait;

public class EbayHome {


By searchtextbox = By.xpath("//*[@id=\'gh-ac\']");
String searchterm = "puma";
By searchbutton = By.xpath("//*[@id=\'gh-btn\']");


public void ebaysearch() throws InterruptedException {
    DriverBela.findElement(searchtextbox).sendKeys(searchterm);
    DriverBela.findElement(searchbutton).click();


    Thread.sleep(5000);


}




}
